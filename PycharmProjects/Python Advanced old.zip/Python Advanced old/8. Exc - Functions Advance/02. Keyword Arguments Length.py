def kwargs_length(**kwargs):
    x = len(kwargs)
    return x


dictionary = {}

print(kwargs_length(**dictionary))
