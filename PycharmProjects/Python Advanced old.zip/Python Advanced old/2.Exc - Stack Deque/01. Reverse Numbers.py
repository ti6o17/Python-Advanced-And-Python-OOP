numbers = input().split(' ')
rev_numbers = reversed(numbers)

print(' '.join([num for num in rev_numbers]))