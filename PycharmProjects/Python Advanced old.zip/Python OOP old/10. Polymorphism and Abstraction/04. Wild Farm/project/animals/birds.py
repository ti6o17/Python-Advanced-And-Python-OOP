from project.animals.animal import Animal

class Birds(Animal):
    def __init__(self)